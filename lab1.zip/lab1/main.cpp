#include <iostream>

using namespace std;

int main()
{
    int   forest_sun, forest_rain, home_sun, home_rain;
    float probability_rain,probability_sun,U_forest,U_home;

    cout << "Enter probability of rain (from 0 to 1)" << endl;
    cin >> probability_rain;

    while (!(probability_rain >= 0) || !(probability_rain <= 1))
    {
        cout<<"This value is wrong!" << endl;
        cout << "Enter probability of rain (from 0 to 1)" << endl;
        cin >> probability_rain;
    }
    probability_sun = 1 - probability_rain;


    cout << "How do you feel in the forest when the weather is sunny?(from 1 to 10)" << endl;
    cin >> forest_sun;

    cout << "How do you feel in the forest when the weather is rainy?(from 1 to 10)" << endl;
    cin >> forest_rain;

    cout << "How do you feel at home when the weather is sunny?(from 1 to 10)" << endl;
    cin >> home_sun;

    cout << "How do you feel at home when the weather is rainy?(from 1 to 10)" << endl;
    cin >> home_rain;

    cout << endl;

    U_forest = probability_sun * forest_sun + probability_rain * forest_rain;
    U_home = probability_sun * home_sun + probability_rain * home_rain;

    cout << "Results:" << endl;
    cout << "Forest - "<< U_forest << endl;
    cout << "Home - "<< U_home << endl;

    if (U_forest > U_home)
        cout<< "Let's go to the forest!" << endl;
    else
        cout << "Stay at home!" << endl;

    return 0;
}

